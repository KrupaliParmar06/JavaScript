let s1 = "Krupali";
let s2 = "Parmar";
let s3 = s1 + " " + s2;
document.write(s3);