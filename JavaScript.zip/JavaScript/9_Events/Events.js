function demoOnClick(){
    alert("On Click");
}

function demoOnDblClick(){
    alert("On Double Click");
}

function demoOnFocus(){
    document.getElementById("txtFocus").style.backgroundColor="Red";
}

function demoOnBlur(){
    document.getElementById("txtBlur").style.backgroundColor="yellow";
}

function demoOnKeypress(){
    alert("Keypress Done");
}

function demoOnKeyUp(){
    alert("KeyUp Done");
}